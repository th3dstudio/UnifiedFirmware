# PlatformIO build action

This action build thanks PIO.

## Inputs

### `cmsis-version`

The CMSIS version to use. Default `"5.9.0"`.

## Example usage

```yaml
uses: ./.github/actions/pio-build
```
