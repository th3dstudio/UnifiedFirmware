#ifdef VIRTIOCON

#include "virtio_config.h"
#include "open-amp/lib/remoteproc/remoteproc_virtio.c"

#endif /* VIRTIOCON */
