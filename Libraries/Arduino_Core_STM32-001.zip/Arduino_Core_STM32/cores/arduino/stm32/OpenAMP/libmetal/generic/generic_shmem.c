#ifdef VIRTIOCON

#include "libmetal/lib/system/generic/generic_shmem.c"

#endif /* VIRTIOCON */
