#ifndef __CMSIS_DSP_H__
#define __CMSIS_DSP_H__

#include "arm_math.h"

#endif /* __CMSIS_DSP_H__ */
