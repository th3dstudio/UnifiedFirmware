                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:2875651
Petsfang Duct for Alfawise U10 by dpetsel is licensed under the Creative Commons - Attribution - Non-Commercial - No Derivatives license.
http://creativecommons.org/licenses/by-nc-nd/3.0/

# Summary

<font size="5" color="brown">Petsfang for Alfawise U10</font>
*****
6.7.2018
New files with right mounting hole refined location. Backplate clip tightened up. 
Routing for wires from right side.
mounting 
*****
<font size="5" color=red >Files starting with u10 are for the stock hot end. </font> 
******

<font size="2">All U10 Files are up.   Thanks to Raymond Borrego for help on the prototype measurements to U10 back plate. It's more than just mirroring the mount! </font> 
*****
If you are looking for the regular Petsfang please follow the link below

https://www.thingiverse.com/thing:2759439

<img src=" https://cdn.thingiverse.com/renders/4d/01/6f/13/83/09d53f4cffe6d69933b4eb9886597013_preview_featured.jpg" width=600 height=1000>




*****

<font size="3"></font> 
*****

I am working on bases and ducts for the Alfawise U10 large format 3d printer. 
Stat tuned as we test these on this new platform.